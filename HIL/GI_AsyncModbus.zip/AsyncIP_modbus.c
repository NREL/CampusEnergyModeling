/*-------------------------------------------------------------------
 *  OPAL-RT Technologies inc
 *
 *  Copyright (C) 2003. All rights reserved.
 *
 *  File name =         AsyncIP.c
 *  Last modified by =  Mathieu Dub�-Dallaire
 *
 *  Code example of an asynchronous program.  This program is started
 *  by the asynchronous controller and demonstrates how to send and 
 *  receive data to and from the asynchronous icons and a UDP or TCP
 *  port.
 *
 *  Feel free to use this as a starting point for your own asynchronous
 *  application. You should normally only have to modify the sections
 *  marked with: ****** Format to specific protocol here. ******.
 *
  *-----------------------------------------------------------------*/

#define PROGNAME "AsyncIP_modbus"

// Standard ANSI C headers needed for this program
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#if defined(__QNXNTO__)
#       include <process.h>
#       include <sys/sched.h>
#       include <pthread.h>
#       include <devctl.h>
#       include <sys/dcmd_chr.h>
#elif defined(__linux__)
#       define _GNU_SOURCE   1
#       include <sched.h>
#	if defined(__redhawk__)
#		include <cpuset.h>
#		include <mpadvise.h>
#endif
#endif

// Define RTLAB before including OpalPrint.h for messages to be sent
// to the OpalDisplay. Otherwise stdout will be used.
#define RTLAB
#include "OpalPrint.h"
#include "AsyncApi.h"
#include "AsyncIPUtils.h"

// This is just for initializing the shared memory access to communicate
// with the RT-LAB model. It's easier to remember the arguments like this
#define	ASYNC_SHMEM_NAME argv[1]
#define ASYNC_SHMEM_SIZE atoi(argv[2])
#define PRINT_SHMEM_NAME argv[3]

// This defines the maximum number of signals (doubles) that can be sent
// or received by any individual Send or Recv block in the model. This
// only applies to the "model <-> asynchronous process" communication.
#define MAXSENDSIZE 64
#define MAXRECVSIZE 64

// Set the stack size of each thread.
#define STACKSIZE 4096

// Use the smallest possible memory footprint to store the data_out
// and data_in structures.
#pragma pack(1)

// ****** FORMAT TO SPECIFIC PROTOCOL HERE ******************************
//
// Define the structure of the data that we send out. This is used in the
// SendToIPPort function
struct data_out
{
  unsigned char  unit_id;           // (1 byte)  Unit identifier
  unsigned char  function;          // (1 byte)  Function code (0x01 to 0x06 only)
  unsigned short data[2]; // Up to MAXSENDSIZE fields (2 bytes each)
  unsigned char  crclow;               // CRC to check data consistency
  unsigned char  crchigh;
} ;
//
// Define the structure of the data that we receive. This is used in the
// RecvFromIPPort function
struct data_in
{
  unsigned char  unit_id;           // (1 byte)  Unit identifier
  unsigned char  function;          // (1 byte)  Function code (0x03 to 0x04 only)
  unsigned char  data[MAXRECVSIZE*2]; // Up to MAXSENDSIZE fields (1 byte each)
};
// **********************************************************************

// Go back to the standard memory allocation scheme.
#pragma pack()

volatile int thread_count = 0;

/************************************************************************/
int AssignProcToCpu0(void)
{
#if defined(__linux__)  
#	if defined(__redhawk__)
	int				rc;
	pid_t			pid = getpid();
	cpuset_t		*pCpuset;

	pCpuset = cpuset_alloc();
	if (NULL == pCpuset)
	{
		fprintf(stderr, "Error allocating a cpuset\n");
		return(ENOMEM);
	}
	cpuset_init(pCpuset);
	cpuset_set_cpu(pCpuset, 0, 1);
	rc = mpadvise(MPA_PRC_SETBIAS, MPA_TID, pid, pCpuset);
	if (MPA_FAILURE == rc)
	{
		rc = errno;
		fprintf(stderr, "Error from mpadvise, %d %s, for pid %d\n", errno, strerror(errno), pid);
		cpuset_free(pCpuset);
		return(rc);
	}
	cpuset_free(pCpuset);
	return EOK;
#	else
	cpu_set_t bindSet;
	CPU_ZERO( &bindSet );
	CPU_SET( 0, &bindSet );
	/* changing process cpu affinity */
	if ( sched_setaffinity( 0, sizeof(cpu_set_t), &bindSet ) != 0 )
	{
		(int) fprintf(stderr, "Unable to bind the process to cpu 0. (sched_setaffinity errno %d)\n", errno );
		return EINVAL;
	}
	return EOK;
#	endif
#endif	// __linux__
}  
/************************************************************************
This function processes the CRC16 of the buffer of data

Parameter IN: data : buffer of data
			  length: length of buffer
return : (2 bytes)CRC
************************************************************************/

unsigned short ProcessCRC16(unsigned char *data, unsigned int length)
{
	int i,j;
	unsigned short CRC=0xFFFF;
	unsigned char temp=0;
	unsigned short G=0xA001;	//polynome caract�ristique
	i=0;
	do
	{
		j=0;
		CRC^=(unsigned short)data[i];
		do
		{
			j++;
			if (CRC%2)
			{
				CRC>>=1;
				CRC=CRC^G;		
			}
			else
			{
				CRC>>=1;
			}
		}while(j<8);
		i++;
	}while(i<length);

return CRC;
	

}
/************************************************************************/

/************************************************************************/
void *SendToIPPort (void * arg)
{
  unsigned int    SendID = 1;
  int    i,n;
  int    nbSend = 0;
  int    ModelState;

  double mdldata[MAXSENDSIZE];
  int    mdldata_size;
  struct data_out comdata;
  int    comdata_size;
  unsigned char *buffertoCRCprocessing;
  OpalPrint("%s: SendToIPPort thread started\n", PROGNAME);
  
  OpalGetNbAsyncSendIcon(&nbSend);
  
  if(nbSend >= 1)
    {
      do
	{
	  // This call unblocks when the 'Data Ready' line of a send icon is asserted.
	  if((n = OpalWaitForAsyncSendRequest (&SendID)) != EOK)
	    {
	      ModelState = OpalGetAsyncModelState();
	      if ((ModelState != STATE_RESET) && (ModelState != STATE_STOP))
		{
		  OpalSetAsyncSendIconError(n, SendID);
		  OpalPrint("%s: OpalWaitForAsyncSendRequest(), errno %d\n", PROGNAME, n);
		}
	      continue;
	    }
	  
	  // No errors encountered yet
	  OpalSetAsyncSendIconError(0, SendID);

	  // Get the size of the data being sent by the unblocking SendID
	  OpalGetAsyncSendIconDataLength (&mdldata_size, SendID);
	  if (mdldata_size/sizeof(double) > MAXSENDSIZE)
	  {
		  OpalPrint("%s: Number of signals for SendID=%d exceeds allowed maximum (%d)\n", PROGNAME, SendID, MAXSENDSIZE);
	      return NULL;
	  }

	  // Read data from the model
	  OpalGetAsyncSendIconData (mdldata, mdldata_size, SendID);

// ****** FORMAT TO SPECIFIC PROTOCOL HERE ******************************
//
// Modify this section to use values differently or to cast them
// to other data types depending on the structure...  
//
	  buffertoCRCprocessing=(unsigned char *)calloc(1,sizeof(comdata));			//buffer for CRC generation 
	  comdata.unit_id  = SendID;												//	Add slave id to Modbus packet
	  buffertoCRCprocessing[0]=comdata.unit_id;
	  comdata_size     = sizeof(comdata.unit_id);								//update packet size


	  comdata.function = (unsigned char)(mdldata[0]);							// Add function to Modbus packet
	  buffertoCRCprocessing[1]= comdata.function;
	  comdata_size     += sizeof(comdata.function) ;	  


	  // we don't need to cast the data from the model to another format
	  for (i=0; i < (mdldata_size / sizeof(double)); i++)
	  {
	    comdata.data[i] = htons((unsigned short)mdldata[i+1]); 
		buffertoCRCprocessing[2+2*i]=(unsigned char)(((unsigned short)mdldata[i+1])>>8);
		buffertoCRCprocessing[3+2*i]=(unsigned char)((unsigned short)mdldata[i+1]);
		
	  }
      comdata_size     +=  (((mdldata_size/sizeof(double))-1) * sizeof(short));


      comdata.crclow   = (unsigned char)ProcessCRC16(buffertoCRCprocessing,comdata_size);	//Add the CRC
	  
      comdata.crchigh  = (unsigned char) (ProcessCRC16(buffertoCRCprocessing,comdata_size)>>8);	
	  
      comdata_size     +=2*sizeof(comdata.crchigh); 
//For Debug
//	  for (i=0;i<comdata_size;i++)
//		OpalPrint(" Data[%d] %hx\n",i,((unsigned char* )(&comdata))[i]);
// **********************************************************************

	  // Perform the actual write to the ip port
	  if (SendPacket((char*)&comdata, comdata_size) < 0)
	    OpalSetAsyncSendIconError  (errno, SendID);
	  else
	    OpalSetAsyncSendIconError  (0, SendID);

	  // This next call allows the execution of the "asynchronous" process
	  // to actually be synchronous with the model. To achieve this, you
	  // should set the "Sending Mode" in the Async_Send block to
	  // NEED_REPLY_BEFORE_NEXT_SEND or NEED_REPLY_NOW. This will force
	  // the model to wait for this process to call this
	  // OpalAsyncSendRequestDone function before continuing.
	  //OpalAsyncSendRequestDone (SendID);

	  // Before continuing, we make sure that the real-time model
	  // has not been stopped. If it has, we quit.
	  ModelState = OpalGetAsyncModelState();
	} while ((ModelState != STATE_RESET) && (ModelState != STATE_STOP));

      OpalPrint("%s: SendToIPPort: Finished\n", PROGNAME);
    }
  
  else
    {
      OpalPrint("%s: SendToIPPort: No transimission block for this controller. Stopping thread.\n", PROGNAME);
    }

  thread_count--;
  free (buffertoCRCprocessing);
  return NULL;
}
/************************************************************************/

/************************************************************************/
void *RecvFromIPPort (void * arg)
{
	int    RecvID = 1;
	int    i, n1, n2, nt, n;
	int    z = 0;
	int    nbRecv = 0;
	int    ModelState;

	double mdldata[MAXRECVSIZE];
	double baseaddress;
	int    mdldata_size;
	struct data_in comdata;
	int    comdata_size,packetlength;
	unsigned short receivedCRC=0,processedCRC=0;
	int id_list[10];
	Opal_RecvAsyncParam	recv_params;
	
	OpalPrint("%s: RecvFromIPPort thread started\n", PROGNAME);  
	OpalGetNbAsyncRecvIcon(&nbRecv);





	if(nbRecv >= 1)
	{

		do
		{

		  memset (&comdata, 0, sizeof(comdata));
		  
// ****** FORMAT TO SPECIFIC PROTOCOL HERE ******************************
//
// Modify this section if your protocol needs to receive more than one
// packet to process the data
		  comdata_size = sizeof(comdata);
		  n  = RecvPacket((char*)&comdata, comdata_size, 1.0);
		  //OpalPrint("RecvPacket %d\n",n);
	      nt = n;
		  if (n < 1)
		  {
			  ModelState = OpalGetAsyncModelState();
			  if ((ModelState != STATE_RESET) && (ModelState != STATE_STOP))
			  {
				  // n ==  0 means timeout, so we continue silently
				  //if (n == 0)
				  //  OpalPrint("%s: Timeout while waiting for data\n", PROGNAME, errno);
					// n == -1 means a more serious error, so we print it
				  if (n == -1)
					  OpalPrint("%s: Error %d while waiting for data\n", PROGNAME, errno);
				  continue;
			  }
			  break;
		  }
		  else if (nt < 5)
		  {
	      // Disable this print. It may happen in TCP/IP mode. The server needs to be modified to check packet size.
		  // OpalPrint("%s: Received incoherent packet (size: %d, complete: %d)\n", PROGNAME, nt, comdata_size);
			  continue;
		  }

// ****** FORMAT TO SPECIFIC PROTOCOL HERE ******************************



	 
	  RecvID = comdata.unit_id;   // Use the unit ID as the RecvID

	  // Get the number of signals to send back to the model
	  OpalGetAsyncRecvIconDataLength (&mdldata_size, RecvID);
	  if (mdldata_size/sizeof(double) > MAXRECVSIZE)
		  OpalPrint("%s: Number of signals for RecvID=%d (%d) exceeds allowed maximum (%d)\n", PROGNAME, RecvID, mdldata_size/sizeof(double), MAXRECVSIZE);
	  
	  //Check the CRC
	  packetlength=5+2*mdldata_size/sizeof(double);//only available for function 3 and 4. To avoid CR/LF data
	  receivedCRC=(((unsigned char*)&comdata)[packetlength-1])<<8|((unsigned char*)&comdata)[packetlength-2];
	  processedCRC=ProcessCRC16(&comdata,packetlength-2);
	  //if (receivedCRC==processedCRC)
	  //{
		  //OpalPrint("CRC OK\n");
	  //}
	  //else
		//  OpalPrint("processed %hx received %hx\n",processedCRC,receivedCRC);


	  
	  // The rest of the processing (unpacking) depends on the function code
	  //
	  
	  if (receivedCRC==processedCRC)
	  {	
		  if (comdata.function & 0x80)
		  {
			  OpalPrint("%s: Received error %d (unit: %d, function: %d, RecvID: %d)\n",PROGNAME,comdata.data[0],comdata.unit_id,comdata.function,RecvID);
			  OpalSetAsyncRecvIconStatus (z++, RecvID); // Increment the Status
			  OpalSetAsyncRecvIconError  (comdata.data[0], RecvID); // Set the Error to the exception code
			  memset (&mdldata, 0, sizeof(mdldata));
		  }
		  else if (comdata.function == 3 || comdata.function == 4)
		  {
			  OpalSetAsyncRecvIconStatus (z++, RecvID); // Increment the Status
			  OpalSetAsyncRecvIconError  (0, RecvID);   // Set the Error to 0
			  
			  // Set the first output to the function code
			  memset (&mdldata, 0, sizeof(mdldata));


			  if(comdata.data[0]!=2*mdldata_size/sizeof(double))
			  {
				  OpalPrint("%s: Unrecognized response for function 3 and 4",PROGNAME);
			  
			  
			  }
			  else
			  {
				  for(i=0;i<mdldata_size/sizeof(double);i++)
				  {
					  mdldata[i]=(double)((comdata.data[1+2*i]<<8)|comdata.data[2+2*i]);
					  //OpalPrint("mdlata[%d] %f\n",i,mdldata[i]);
				  }
				 // for(i=0;i<comdata.data[0];i++)
				//	  OpalPrint("Data[%d] %hx\n",i,comdata.data[1+i]);
				  OpalGetAsyncRecvParameters(&recv_params, sizeof(Opal_RecvAsyncParam), 18);
				  baseaddress=	recv_params.FloatParam[0];  //Base address sending: this parameter should be used for scaling processing
															//Depends the base address value you can retrieve the registers address and from
														    // register address you can apply the good scaling
				  OpalPrint("base address %f",baseaddress);
/***************************************************************Scaling**********************************************/					
				//Example of scale processing
				 //for(i=0;i<mdldata_size/sizeof(double);i++)
				 //{
						//if((baseaddress+i==0x2558)||(baseaddress+i==0x255B)||(baseaddress+i==0x255E)||(baseaddress+i==0x2561)||(baseaddress+i==0x2564)||(baseaddress+i==0x2567))
						//{
								//apply the scale on the raw data
								//mdldata[i]*=scale_F060;
						//}
						//if((baseaddress+i==0x255A)||(baseaddress+i==0x2560)||(baseaddress+i==0x2563)||(baseaddress+i==0x255D)||(baseaddress+i==0x2566)||(baseaddress+i==0x2569))
						//{
								//apply the scale on the raw data
								//mdldata[i]*=scale_F002;
						//}
						//if((baseaddress+i==0x256A)||(baseaddress+i==0x256C))
						//{
								//apply the scale on the raw data
								//mdldata[i]*=scale_F003;
						//}
				  
				// }	
					
			  
			  }

		}

	    // Unhandled function code
		else
		{
			OpalPrint("%s: Unrecognized function code %d for RecvID %d\n", PROGNAME, comdata.function, RecvID);
			OpalSetAsyncRecvIconStatus (z++, RecvID); // Increment the Status
			OpalSetAsyncRecvIconError  (-1, RecvID);  // Set the Error to -1
			memset (&mdldata, 0, sizeof(mdldata));
		}
	}
	else
		OpalPrint("%s: Invalid CRC; Processed %hx Received %hx\n", PROGNAME, processedCRC, receivedCRC);









// **********************************************************************

	  OpalSetAsyncRecvIconData (mdldata, mdldata_size, RecvID);
	  OpalAsyncSendRequestDone (RecvID);

	  // Before continuing, we make sure that the real-time model
	  // has not been stopped. If it has, we quit.
	  ModelState = OpalGetAsyncModelState();
	} while ((ModelState != STATE_RESET) && (ModelState != STATE_STOP));

      OpalPrint("%s: RecvFromIPPort: Finished\n", PROGNAME);
    }
  else
    {
      OpalPrint("%s: RecvFromIPPort: No reception block for this controller. Stopping thread.\n", PROGNAME);
    }
  
  thread_count--;
  return NULL;
}
/************************************************************************/

/************************************************************************/
int main (int argc, char *argv[]) 
{
  Opal_GenAsyncParam_Ctrl IconCtrlStruct;
  int err;
  pthread_t      tid_send,  tid_recv;
  pthread_attr_t attr_send, attr_recv;
  
  // Check for the proper arguments to the program
  if (argc < 4)
    {
      printf("Invalid Arguments: 1-AsyncShmemName 2-AsyncShmemSize 3-PrintShmemName\n");
      exit(0);
    }
  
  // Enable the OpalPrint function. This prints to the OpalDisplay.
  if (OpalSystemCtrl_Register(PRINT_SHMEM_NAME) != EOK)
    {
      printf("%s: ERROR: OpalPrint() access not available\n", PROGNAME);
      exit(-1);	
    }
  
  // Open Share Memory created by the model. -----------------------
  if((OpalOpenAsyncMem (ASYNC_SHMEM_SIZE, ASYNC_SHMEM_NAME)) != EOK)
    {
      OpalPrint("%s: ERROR: Model shared memory not available\n", PROGNAME);
      exit(-1);
    }
  
  // For Redhawk, Assign this process to CPU 0 in order to support partial XHP
  AssignProcToCpu0();  

  // Get IP Controler Parameters (ie: ip address, port number...) and
  // initialize the device on the QNX node.
  memset(&IconCtrlStruct, 0, sizeof(IconCtrlStruct));
  if((err = OpalGetAsyncCtrlParameters(&IconCtrlStruct, sizeof(IconCtrlStruct))) != EOK)
    {
      OpalPrint("%s: ERROR: Could not get controller parameters (%d).\n", PROGNAME, err);
      exit(-1);
    }
  if(InitSocket (IconCtrlStruct) != EOK)
    {
      OpalPrint("%s: ERROR: Initialization failed.\n", PROGNAME);
      exit(-1);
    }

  // Start transmission thread --------------------------------------
  thread_count++;
  pthread_attr_init (&attr_send);
  //pthread_attr_setstacksize (&attr_send, STACKSIZE); // Has been known to crash the application
  if ((pthread_create (&tid_send, &attr_send, SendToIPPort, NULL)) == -1)
    {
      OpalPrint("%s: ERROR: Could not create thread (SendToIPPort), errno %d\n", PROGNAME, errno);
      thread_count--;
    }
  // Start reception thread -----------------------------------------
  thread_count++;
  pthread_attr_init (&attr_recv);
  //pthread_attr_setstacksize (&attr_recv, STACKSIZE); // Has been known to crash the application
  if ((pthread_create (&tid_recv, &attr_recv, RecvFromIPPort, NULL)) == -1)
    {
      OpalPrint("%s: ERROR: Could not create thread (RecvFromIPPort), errno %d\n", PROGNAME, errno);
      thread_count--;
    }

  // Wait for both threads to finish --------------------------------
  if ((err = pthread_join (tid_send, NULL)) != 0)
    { OpalPrint("%s: ERROR: pthread_join (SendToIPPort), errno %d\n", PROGNAME, err); }
  if ((err = pthread_join (tid_recv, NULL)) != 0)
    { OpalPrint("%s: ERROR: pthread_join (RecvFromIPPort), errno %d\n", PROGNAME, err); }

  // Close the ip port and shared memories ----------------------
  CloseSocket (IconCtrlStruct);
  OpalCloseAsyncMem (ASYNC_SHMEM_SIZE,ASYNC_SHMEM_NAME);
  OpalSystemCtrl_UnRegister(PRINT_SHMEM_NAME);

  return(0);
}
/************************************************************************/
